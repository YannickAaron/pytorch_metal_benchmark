from ._feature import _Feature


class SegmentationMask(_Feature):
    pass
