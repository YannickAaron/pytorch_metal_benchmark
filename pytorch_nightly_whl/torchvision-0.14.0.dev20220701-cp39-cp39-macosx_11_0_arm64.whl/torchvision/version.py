__version__ = '0.14.0.dev20220701'
git_version = '1f74251043de2de5b772bbfcea5a51a0b6013b57'
from torchvision.extension import _check_cuda_version
if _check_cuda_version() > 0:
    cuda = _check_cuda_version()
